from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
import os
import sqlite3

app = Flask(__name__)
app.secret_key = 'supersecretkey'

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, 'database.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static/uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def init_db():
    with sqlite3.connect(DATABASE_PATH) as conn:
        conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT
        )''')

        conn.execute('''
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY,
            title TEXT,
            description TEXT,
            file TEXT,
            status TEXT,
            user_id INTEGER
        )''')

@app.route('/')
def index():
    with sqlite3.connect(DATABASE_PATH) as conn:
        projects = conn.execute('SELECT * FROM projects WHERE status="approved"').fetchall()
    return render_template('index.html', projects=projects)

@app.route('/browse')
def browse():
    with sqlite3.connect(DATABASE_PATH) as conn:
        projects = conn.execute('SELECT * FROM projects WHERE status="approved"').fetchall()
    return render_template('browse.html', projects=projects)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        role = 'student'

        with sqlite3.connect(DATABASE_PATH) as conn:
            try:
                conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                             (username, password, role))
                conn.commit()
                return redirect(url_for('login'))
            except sqlite3.IntegrityError:
                return "Username already exists"
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()

        with sqlite3.connect(DATABASE_PATH) as conn:
            user = conn.execute('SELECT * FROM users WHERE username=? AND password=?',
                                (username, password)).fetchone()
            if user:
                session['user_id'] = user[0]
                session['username'] = user[1]
                session['role'] = user[3]
                return redirect(url_for('index'))
            else:
                error = "Invalid username or password"
                return render_template('login.html', error=error)
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        file = request.files['file']
        filename = file.filename
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        with sqlite3.connect(DATABASE_PATH) as conn:
            conn.execute('INSERT INTO projects (title, description, file, status, user_id) VALUES (?, ?, ?, ?, ?)',
                         (title, description, filename, "pending", session['user_id']))
        return redirect(url_for('index'))

    return render_template('upload.html')

@app.route('/admin')
def admin():
    if session.get('role') != 'admin':
        return 'Access denied'
    with sqlite3.connect(DATABASE_PATH) as conn:
        projects = conn.execute('SELECT * FROM projects').fetchall()
    return render_template('admin.html', projects=projects)

@app.route('/approve/<int:id>')
def approve(id):
    if session.get('role') != 'admin':
        return 'Access denied'
    with sqlite3.connect(DATABASE_PATH) as conn:
        conn.execute('UPDATE projects SET status="approved" WHERE id=?', (id,))
    return redirect(url_for('admin'))

@app.route('/project/<int:id>')
def project_detail(id):
    with sqlite3.connect(DATABASE_PATH) as conn:
        project = conn.execute('SELECT * FROM projects WHERE id=?', (id,)).fetchone()
    return render_template('project_detail.html', project=project)

# ✅ FIXED: Route to serve uploaded files
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
